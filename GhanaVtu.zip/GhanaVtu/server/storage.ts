import {
  users,
  networks,
  serviceTypes,
  servicePackages,
  transactions,
  balanceTransactions,
  type User,
  type UpsertUser,
  type Network,
  type ServiceType,
  type ServicePackage,
  type Transaction,
  type BalanceTransaction,
  type InsertNetwork,
  type InsertServiceType,
  type InsertServicePackage,
  type InsertTransaction,
  type InsertBalanceTransaction,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserBalance(userId: string, amount: number): Promise<User | undefined>;

  // Network operations
  getNetworks(): Promise<Network[]>;
  getNetworkById(id: string): Promise<Network | undefined>;
  createNetwork(network: InsertNetwork): Promise<Network>;

  // Service type operations
  getServiceTypes(): Promise<ServiceType[]>;
  getServiceTypeById(id: string): Promise<ServiceType | undefined>;
  createServiceType(serviceType: InsertServiceType): Promise<ServiceType>;

  // Service package operations
  getServicePackages(networkId?: string, serviceTypeId?: string): Promise<ServicePackage[]>;
  getServicePackageById(id: string): Promise<ServicePackage | undefined>;
  createServicePackage(servicePackage: InsertServicePackage): Promise<ServicePackage>;

  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: string, status: string, completedAt?: Date): Promise<Transaction | undefined>;
  getTransactionsByUser(userId: string, limit?: number): Promise<Transaction[]>;
  getTransactionById(id: string): Promise<Transaction | undefined>;

  // Balance transaction operations
  createBalanceTransaction(balanceTransaction: InsertBalanceTransaction): Promise<BalanceTransaction>;
  getBalanceTransactionsByUser(userId: string, limit?: number): Promise<BalanceTransaction[]>;

  // Analytics
  getUserStats(userId: string): Promise<{
    totalTransactions: number;
    totalVolume: number;
    totalCommission: number;
    thisMonthTransactions: number;
    thisMonthVolume: number;
    thisMonthCommission: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private networks: Map<string, Network>;
  private serviceTypes: Map<string, ServiceType>;
  private servicePackages: Map<string, ServicePackage>;
  private transactions: Map<string, Transaction>;
  private balanceTransactions: Map<string, BalanceTransaction>;

  constructor() {
    this.users = new Map();
    this.networks = new Map();
    this.serviceTypes = new Map();
    this.servicePackages = new Map();
    this.transactions = new Map();
    this.balanceTransactions = new Map();

    // Initialize with Ghana networks and services
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Ghana networks
    const ghanaNetworks: Network[] = [
      {
        id: "mtn",
        name: "mtn",
        displayName: "MTN Ghana",
        logoUrl: null,
        discountRate: "1.00",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "vodafone",
        name: "vodafone",
        displayName: "Telecel (Vodafone)",
        logoUrl: null,
        discountRate: "4.00",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "airteltigo",
        name: "airteltigo",
        displayName: "AirtelTigo",
        logoUrl: null,
        discountRate: "4.00",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "glo",
        name: "glo",
        displayName: "Glo Ghana",
        logoUrl: null,
        discountRate: "2.00",
        isActive: true,
        createdAt: new Date(),
      },
    ];

    ghanaNetworks.forEach(network => this.networks.set(network.id, network));

    // Service types
    const services: ServiceType[] = [
      {
        id: "airtime",
        name: "airtime",
        displayName: "Airtime",
        description: "Mobile airtime recharge",
        isActive: true,
      },
      {
        id: "data",
        name: "data",
        displayName: "Data Bundle",
        description: "Internet data packages",
        isActive: true,
      },
      {
        id: "sms",
        name: "sms",
        displayName: "SMS Bundle",
        description: "SMS packages",
        isActive: true,
      },
    ];

    services.forEach(service => this.serviceTypes.set(service.id, service));

    // Data packages for each network
    const dataPackages: Omit<ServicePackage, "id" | "createdAt">[] = [
      // MTN Data Packages
      { networkId: "mtn", serviceTypeId: "data", name: "MTN 1GB", description: "1GB data valid for 7", amount: "5.00", validity: "7", dataAllowance: "1GB", isActive: true },
      { networkId: "mtn", serviceTypeId: "data", name: "MTN 3GB", description: "3GB data valid for 30", amount: "12.00", validity: "30", dataAllowance: "3GB", isActive: true },
      { networkId: "mtn", serviceTypeId: "data", name: "MTN 6GB", description: "6GB data valid for 30", amount: "20.00", validity: "30", dataAllowance: "6GB", isActive: true },
      { networkId: "mtn", serviceTypeId: "data", name: "MTN 12GB", description: "12GB data valid for 30", amount: "35.00", validity: "30", dataAllowance: "12GB", isActive: true },

      // Vodafone/Telecel Data Packages
      { networkId: "vodafone", serviceTypeId: "data", name: "Telecel 1GB", description: "1GB data valid for 7", amount: "5.00", validity: "7", dataAllowance: "1GB", isActive: true },
      { networkId: "vodafone", serviceTypeId: "data", name: "Telecel 3GB", description: "3GB data valid for 30", amount: "12.00", validity: "30", dataAllowance: "3GB", isActive: true },
      { networkId: "vodafone", serviceTypeId: "data", name: "Telecel 6GB", description: "6GB data valid for 30", amount: "20.00", validity: "30", dataAllowance: "6GB", isActive: true },
      { networkId: "vodafone", serviceTypeId: "data", name: "Telecel 12GB", description: "12GB data valid for 30", amount: "35.00", validity: "30", dataAllowance: "12GB", isActive: true },

      // AirtelTigo Data Packages
      { networkId: "airteltigo", serviceTypeId: "data", name: "AirtelTigo 1GB", description: "1GB data valid for 7", amount: "5.00", validity: "7", dataAllowance: "1GB", isActive: true },
      { networkId: "airteltigo", serviceTypeId: "data", name: "AirtelTigo 3GB", description: "3GB data valid for 30", amount: "12.00", validity: "30", dataAllowance: "3GB", isActive: true },
      { networkId: "airteltigo", serviceTypeId: "data", name: "AirtelTigo 6GB", description: "6GB data valid for 30", amount: "20.00", validity: "30", dataAllowance: "6GB", isActive: true },
      { networkId: "airteltigo", serviceTypeId: "data", name: "AirtelTigo 12GB", description: "12GB data valid for 30", amount: "35.00", validity: "30", dataAllowance: "12GB", isActive: true },

      // Glo Data Packages
      { networkId: "glo", serviceTypeId: "data", name: "Glo 1GB", description: "1GB data valid for 7", amount: "5.00", validity: "7", dataAllowance: "1GB", isActive: true },
      { networkId: "glo", serviceTypeId: "data", name: "Glo 3GB", description: "3GB data valid for 30", amount: "12.00", validity: "30", dataAllowance: "3GB", isActive: true },
      { networkId: "glo", serviceTypeId: "data", name: "Glo 6GB", description: "6GB data valid for 30", amount: "20.00", validity: "30", dataAllowance: "6GB", isActive: true },
      { networkId: "glo", serviceTypeId: "data", name: "Glo 12GB", description: "12GB data valid for 30", amount: "35.00", validity: "30", dataAllowance: "12GB", isActive: true },
    ];

    dataPackages.forEach(pkg => {
      const id = randomUUID();
      const servicePackage: ServicePackage = {
        ...pkg,
        id,
        createdAt: new Date(),
      };
      this.servicePackages.set(id, servicePackage);
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = Array.from(this.users.values()).find(u => u.email === userData.email);
    
    if (existingUser) {
      const updatedUser: User = {
        ...existingUser,
        ...userData,
        updatedAt: new Date(),
      };
      this.users.set(existingUser.id, updatedUser);
      return updatedUser;
    }

    const id = randomUUID();
    const user: User = {
      ...userData,
      id,
      balance: "0.00",
      commissionRate: "0.00",
      accountType: "individual",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(userId: string, amount: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;

    const currentBalance = parseFloat(user.balance);
    const newBalance = currentBalance + amount;
    
    const updatedUser: User = {
      ...user,
      balance: newBalance.toFixed(2),
      updatedAt: new Date(),
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Network operations
  async getNetworks(): Promise<Network[]> {
    return Array.from(this.networks.values()).filter(n => n.isActive);
  }

  async getNetworkById(id: string): Promise<Network | undefined> {
    return this.networks.get(id);
  }

  async createNetwork(network: InsertNetwork): Promise<Network> {
    const newNetwork: Network = {
      ...network,
      createdAt: new Date(),
    };
    this.networks.set(network.id, newNetwork);
    return newNetwork;
  }

  // Service type operations
  async getServiceTypes(): Promise<ServiceType[]> {
    return Array.from(this.serviceTypes.values()).filter(s => s.isActive);
  }

  async getServiceTypeById(id: string): Promise<ServiceType | undefined> {
    return this.serviceTypes.get(id);
  }

  async createServiceType(serviceType: InsertServiceType): Promise<ServiceType> {
    this.serviceTypes.set(serviceType.id, serviceType);
    return serviceType;
  }

  // Service package operations
  async getServicePackages(networkId?: string, serviceTypeId?: string): Promise<ServicePackage[]> {
    let packages = Array.from(this.servicePackages.values()).filter(p => p.isActive);
    
    if (networkId) {
      packages = packages.filter(p => p.networkId === networkId);
    }
    
    if (serviceTypeId) {
      packages = packages.filter(p => p.serviceTypeId === serviceTypeId);
    }
    
    return packages;
  }

  async getServicePackageById(id: string): Promise<ServicePackage | undefined> {
    return this.servicePackages.get(id);
  }

  async createServicePackage(servicePackage: InsertServicePackage): Promise<ServicePackage> {
    const id = randomUUID();
    const newPackage: ServicePackage = {
      ...servicePackage,
      id,
      createdAt: new Date(),
    };
    this.servicePackages.set(id, newPackage);
    return newPackage;
  }

  // Transaction operations
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const newTransaction: Transaction = {
      ...transaction,
      id,
      status: "pending",
      createdAt: new Date(),
      completedAt: null,
    };
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async updateTransactionStatus(id: string, status: string, completedAt?: Date): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (!transaction) return undefined;

    const updatedTransaction: Transaction = {
      ...transaction,
      status,
      completedAt: completedAt || (status === "successful" ? new Date() : null),
    };
    
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }

  async getTransactionsByUser(userId: string, limit = 50): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(t => t.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getTransactionById(id: string): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  // Balance transaction operations
  async createBalanceTransaction(balanceTransaction: InsertBalanceTransaction): Promise<BalanceTransaction> {
    const id = randomUUID();
    const newBalanceTransaction: BalanceTransaction = {
      ...balanceTransaction,
      id,
      createdAt: new Date(),
    };
    this.balanceTransactions.set(id, newBalanceTransaction);
    return newBalanceTransaction;
  }

  async getBalanceTransactionsByUser(userId: string, limit = 50): Promise<BalanceTransaction[]> {
    return Array.from(this.balanceTransactions.values())
      .filter(bt => bt.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  // Analytics
  async getUserStats(userId: string): Promise<{
    totalTransactions: number;
    totalVolume: number;
    totalCommission: number;
    thisMonthTransactions: number;
    thisMonthVolume: number;
    thisMonthCommission: number;
  }> {
    const userTransactions = Array.from(this.transactions.values())
      .filter(t => t.userId === userId && t.status === "successful");

    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const thisMonthTransactions = userTransactions.filter(t => t.completedAt && t.completedAt >= thisMonth);

    return {
      totalTransactions: userTransactions.length,
      totalVolume: userTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0),
      totalCommission: userTransactions.reduce((sum, t) => sum + parseFloat(t.commission), 0),
      thisMonthTransactions: thisMonthTransactions.length,
      thisMonthVolume: thisMonthTransactions.reduce((sum, t) => sum + parseFloat(t.amount), 0),
      thisMonthCommission: thisMonthTransactions.reduce((sum, t) => sum + parseFloat(t.commission), 0),
    };
  }
}

export const storage = new MemStorage();
