import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { rechargeRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Networks API
  app.get('/api/networks', async (req, res) => {
    try {
      const networks = await storage.getNetworks();
      res.json(networks);
    } catch (error) {
      console.error("Error fetching networks:", error);
      res.status(500).json({ message: "Failed to fetch networks" });
    }
  });

  // Service types API
  app.get('/api/service-types', async (req, res) => {
    try {
      const serviceTypes = await storage.getServiceTypes();
      res.json(serviceTypes);
    } catch (error) {
      console.error("Error fetching service types:", error);
      res.status(500).json({ message: "Failed to fetch service types" });
    }
  });

  // Service packages API
  app.get('/api/service-packages', async (req, res) => {
    try {
      const { networkId, serviceTypeId } = req.query;
      const packages = await storage.getServicePackages(
        networkId as string,
        serviceTypeId as string
      );
      res.json(packages);
    } catch (error) {
      console.error("Error fetching service packages:", error);
      res.status(500).json({ message: "Failed to fetch service packages" });
    }
  });

  // User transactions
  app.get('/api/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const transactions = await storage.getTransactionsByUser(userId, limit);
      
      // Include network and service type information
      const enrichedTransactions = await Promise.all(
        transactions.map(async (transaction) => {
          const network = await storage.getNetworkById(transaction.networkId);
          const serviceType = await storage.getServiceTypeById(transaction.serviceTypeId);
          const servicePackage = transaction.packageId 
            ? await storage.getServicePackageById(transaction.packageId)
            : null;
          
          return {
            ...transaction,
            network,
            serviceType,
            servicePackage,
          };
        })
      );
      
      res.json(enrichedTransactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // User balance transactions
  app.get('/api/balance-transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const balanceTransactions = await storage.getBalanceTransactionsByUser(userId, limit);
      res.json(balanceTransactions);
    } catch (error) {
      console.error("Error fetching balance transactions:", error);
      res.status(500).json({ message: "Failed to fetch balance transactions" });
    }
  });

  // User stats
  app.get('/api/user/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // Process recharge
  app.post('/api/recharge', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const validatedData = rechargeRequestSchema.parse(req.body);
      
      // Check if network and service type exist
      const network = await storage.getNetworkById(validatedData.networkId);
      const serviceType = await storage.getServiceTypeById(validatedData.serviceTypeId);
      
      if (!network || !serviceType) {
        return res.status(400).json({ message: "Invalid network or service type" });
      }

      // Check if package exists for data bundles
      let servicePackage = null;
      if (validatedData.packageId) {
        servicePackage = await storage.getServicePackageById(validatedData.packageId);
        if (!servicePackage) {
          return res.status(400).json({ message: "Invalid service package" });
        }
      }

      // Calculate commission based on user account type and network discount
      const discountRate = parseFloat(network.discountRate);
      const userCommissionRate = parseFloat(user.commissionRate);
      const commission = (validatedData.amount * Math.max(discountRate, userCommissionRate)) / 100;

      // Create transaction
      const transaction = await storage.createTransaction({
        userId,
        networkId: validatedData.networkId,
        serviceTypeId: validatedData.serviceTypeId,
        packageId: validatedData.packageId || null,
        phoneNumber: validatedData.phoneNumber,
        amount: validatedData.amount.toFixed(2),
        commission: commission.toFixed(2),
        paymentMethod: validatedData.paymentMethod,
        referenceId: `VTU-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        description: servicePackage 
          ? `${servicePackage.name} for ${validatedData.phoneNumber}`
          : `${serviceType.displayName} GHS ${validatedData.amount} for ${validatedData.phoneNumber}`,
      });

      // Simulate payment processing
      setTimeout(async () => {
        try {
          // Update transaction status to successful
          await storage.updateTransactionStatus(transaction.id, "successful");
          
          // Add commission to user balance if user is a reseller
          if (commission > 0) {
            await storage.updateUserBalance(userId, commission);
            await storage.createBalanceTransaction({
              userId,
              type: "credit",
              amount: commission.toFixed(2),
              description: `Commission from transaction ${transaction.referenceId}`,
              referenceId: transaction.id,
            });
          }
        } catch (error) {
          console.error("Error processing transaction:", error);
          await storage.updateTransactionStatus(transaction.id, "failed");
        }
      }, 3000); // Simulate 3 second processing time

      res.json({
        success: true,
        transaction: {
          ...transaction,
          network,
          serviceType,
          servicePackage,
        },
        message: "Transaction initiated successfully. You will receive a confirmation shortly.",
      });
    } catch (error) {
      console.error("Error processing recharge:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to process recharge" });
    }
  });

  // Add funds to user balance
  app.post('/api/add-funds', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { amount, paymentMethod } = req.body;

      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      if (!paymentMethod) {
        return res.status(400).json({ message: "Payment method is required" });
      }

      // Simulate payment processing
      const referenceId = `FUND-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      setTimeout(async () => {
        try {
          // Add funds to user balance
          await storage.updateUserBalance(userId, amount);
          await storage.createBalanceTransaction({
            userId,
            type: "credit",
            amount: amount.toFixed(2),
            description: `Funds added via ${paymentMethod}`,
            referenceId,
          });
        } catch (error) {
          console.error("Error adding funds:", error);
        }
      }, 2000);

      res.json({
        success: true,
        referenceId,
        message: "Funds are being added to your account. Please wait for confirmation.",
      });
    } catch (error) {
      console.error("Error adding funds:", error);
      res.status(500).json({ message: "Failed to add funds" });
    }
  });

  // Update user account type
  app.patch('/api/user/account-type', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { accountType } = req.body;

      if (!["individual", "reseller", "enterprise"].includes(accountType)) {
        return res.status(400).json({ message: "Invalid account type" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Set commission rate based on account type
      let commissionRate = "0.00";
      if (accountType === "reseller") {
        commissionRate = "2.50";
      } else if (accountType === "enterprise") {
        commissionRate = "3.50";
      }

      // This would normally update the database, but for the in-memory implementation
      // we'll simulate it by updating the user directly
      const updatedUser = {
        ...user,
        accountType,
        commissionRate,
        updatedAt: new Date(),
      };

      // Update in storage (this is a simplified approach for MemStorage)
      const userMap = (storage as any).users;
      userMap.set(userId, updatedUser);

      res.json({
        success: true,
        user: updatedUser,
        message: `Account upgraded to ${accountType}`,
      });
    } catch (error) {
      console.error("Error updating account type:", error);
      res.status(500).json({ message: "Failed to update account type" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
