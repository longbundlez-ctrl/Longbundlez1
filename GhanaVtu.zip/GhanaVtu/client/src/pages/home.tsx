import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import RechargeForm from "@/components/RechargeForm";
import TransactionHistory from "@/components/TransactionHistory";
import { formatCurrency } from "@/lib/currency";
import { Wallet, TrendingUp, Activity, Plus } from "lucide-react";

export default function Home() {
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/user/stats"],
  });

  const { data: networks } = useQuery({
    queryKey: ["/api/networks"],
  });

  if (userLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header />
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-ghana-red"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      
      {/* Welcome Section */}
      <section className="bg-gradient-to-r from-ghana-red to-ghana-green text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2" data-testid="text-welcome-user">
                Welcome back, {user?.firstName || 'User'}!
              </h1>
              <p className="text-white/80">Account Balance: 
                <span className="font-semibold text-ghana-gold ml-2" data-testid="text-user-balance">
                  {formatCurrency(parseFloat(user?.balance || "0"))}
                </span>
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-white/80">Account Type</p>
              <p className="font-semibold capitalize" data-testid="text-account-type">
                {user?.accountType || 'Individual'}
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span>Quick Actions</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/recharge">
                  <Button className="w-full bg-ghana-red text-white hover:bg-red-700 justify-start" data-testid="button-quick-recharge">
                    <Plus className="w-4 h-4 mr-2" />
                    Quick Recharge
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="outline" className="w-full justify-start" data-testid="button-view-dashboard">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Dashboard
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => {/* Implement add funds modal */}}
                  data-testid="button-add-funds"
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  Add Funds
                </Button>
              </CardContent>
            </Card>

            {/* Account Stats */}
            {!statsLoading && stats && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>This Month</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Transactions</span>
                      <span className="font-semibold" data-testid="text-month-transactions">
                        {stats.thisMonthTransactions}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Volume</span>
                      <span className="font-semibold" data-testid="text-month-volume">
                        {formatCurrency(stats.thisMonthVolume)}
                      </span>
                    </div>
                    {user?.accountType !== "individual" && (
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Commission</span>
                        <span className="font-semibold text-ghana-green" data-testid="text-month-commission">
                          {formatCurrency(stats.thisMonthCommission)}
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Supported Networks */}
            {networks && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Supported Networks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {networks.map((network: any) => (
                      <div key={network.id} className="flex items-center justify-between">
                        <span className="font-medium" data-testid={`text-network-${network.id}`}>
                          {network.displayName}
                        </span>
                        <span className="text-sm text-ghana-green">
                          {network.discountRate}% discount
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Recharge Form */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Recharge</CardTitle>
              </CardHeader>
              <CardContent>
                <RechargeForm />
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Recent Transactions</span>
                  <Link href="/dashboard">
                    <Button variant="ghost" size="sm" data-testid="link-view-all-transactions">
                      View All
                    </Button>
                  </Link>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <TransactionHistory limit={5} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
