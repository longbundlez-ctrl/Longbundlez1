import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import RechargeForm from "@/components/RechargeForm";
import { Phone, Wifi, MessageSquare } from "lucide-react";

export default function Recharge() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header />
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-ghana-red"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will be redirected by useEffect
  }

  const serviceTypes = [
    {
      id: "airtime",
      name: "Airtime",
      description: "Mobile airtime recharge for all networks",
      icon: Phone,
      features: ["Instant delivery", "All networks", "Bulk recharge"]
    },
    {
      id: "data",
      name: "Data Bundle",
      description: "Internet data packages with various validity periods",
      icon: Wifi,
      features: ["1GB to 12GB packages", "Daily to monthly plans", "Auto-renewal options"]
    },
    {
      id: "sms",
      name: "SMS Bundle",
      description: "SMS packages for all networks",
      icon: MessageSquare,
      features: ["Text message bundles", "Bulk SMS options", "Cross-network support"]
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-ghana-red to-ghana-green text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4" data-testid="text-recharge-title">
              Mobile Recharge Services
            </h1>
            <p className="text-xl text-white/90">
              Instant airtime, data bundles, and SMS packages for all Ghana networks
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Service Types */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Available Services</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {serviceTypes.map((service) => (
                  <div key={service.id} className="p-4 border border-neutral-200 rounded-lg hover:border-ghana-red transition-colors">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-ghana-red/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <service.icon className="w-5 h-5 text-ghana-red" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-neutral-900 mb-1" data-testid={`text-service-${service.id}`}>
                          {service.name}
                        </h3>
                        <p className="text-sm text-neutral-600 mb-2">{service.description}</p>
                        <ul className="text-xs text-neutral-500 space-y-1">
                          {service.features.map((feature, index) => (
                            <li key={index}>• {feature}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Help & Support */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Need Help?</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Transaction Issues</h4>
                    <p className="text-neutral-600">If your transaction fails, you'll receive a refund automatically within 5 minutes.</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Support Hours</h4>
                    <p className="text-neutral-600">24/7 customer support via WhatsApp, email, or phone.</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-neutral-900 mb-1">Processing Time</h4>
                    <p className="text-neutral-600">Most transactions are completed within 30 seconds.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recharge Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Mobile Recharge</CardTitle>
              </CardHeader>
              <CardContent>
                <RechargeForm showNetworkInfo={true} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
