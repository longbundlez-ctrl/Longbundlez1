import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import { Shield, Clock, CheckCircle, Phone, Wifi, Receipt, Users, ShieldCheck, Lock, Headphones } from "lucide-react";

export default function Landing() {
  const networks = [
    { name: "MTN Ghana", discount: "1% discount", color: "bg-yellow-500" },
    { name: "Telecel", discount: "4% discount", color: "bg-red-500" },
    { name: "AirtelTigo", discount: "4% discount", color: "bg-blue-500" },
    { name: "Glo Ghana", discount: "Special rates", color: "bg-green-500" },
  ];

  const services = [
    {
      icon: Phone,
      title: "Airtime Recharge",
      description: "Instant airtime top-up for MTN, Vodafone, AirtelTigo networks.",
      features: ["All networks supported", "Instant delivery", "Bulk recharge available"]
    },
    {
      icon: Wifi,
      title: "Data Bundles",
      description: "Affordable data packages for all networks with instant activation.",
      features: ["Daily, weekly, monthly plans", "Up to 4% discount", "Auto-renewal options"]
    },
    {
      icon: Receipt,
      title: "Bill Payments",
      description: "Pay electricity, cable TV, and utility bills seamlessly.",
      features: ["ECG/NEDCo electricity", "DStv/GOtv/StarTimes", "Water bills"]
    },
    {
      icon: Users,
      title: "Reseller Program",
      description: "Earn commissions by becoming a VTU reseller agent.",
      features: ["Up to 3.5% commission", "Real-time dashboard", "Bulk pricing tiers"]
    },
  ];

  const trustFeatures = [
    { icon: ShieldCheck, title: "SSL Encryption", description: "Bank-level security for all transactions" },
    { icon: Lock, title: "PCI Compliant", description: "Industry standard payment security" },
    { icon: Clock, title: "24/7 Monitoring", description: "Real-time fraud detection and prevention" },
    { icon: Headphones, title: "Expert Support", description: "Dedicated customer success team" },
  ];

  const dataPackages = [
    { data: "1GB", price: "GHS 5.00", validity: "7 days" },
    { data: "3GB", price: "GHS 12.00", validity: "30 days" },
    { data: "6GB", price: "GHS 20.00", validity: "30 days" },
    { data: "12GB", price: "GHS 35.00", validity: "30 days" },
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-ghana-red via-red-600 to-ghana-green text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Ghana's Most Trusted<br />
                <span className="text-ghana-gold">Mobile Recharge</span> Platform
              </h1>
              <p className="text-xl mb-8 text-white/90">
                Instant airtime, data bundles, and bill payments for all networks. Fast, secure, and reliable service with 24/7 support.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="bg-white text-ghana-red px-8 py-4 h-auto text-lg font-semibold hover:bg-neutral-100"
                  data-testid="button-start-recharging"
                >
                  Start Recharging Now
                </Button>
                <Button
                  variant="outline"
                  className="border-2 border-white text-white px-8 py-4 h-auto text-lg font-semibold hover:bg-white hover:text-ghana-red"
                  data-testid="button-become-reseller"
                >
                  Become a Reseller
                </Button>
              </div>
              
              {/* Trust Indicators */}
              <div className="mt-12 flex items-center space-x-8">
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-ghana-gold" />
                  <span className="text-sm">SSL Secured</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-ghana-gold" />
                  <span className="text-sm">24/7 Support</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-ghana-gold" />
                  <span className="text-sm">Instant Delivery</span>
                </div>
              </div>
            </div>
            
            {/* Hero Image */}
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556075798-4825dfaaf498?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Mobile payment services in Ghana" 
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-6 shadow-xl">
                <div className="text-ghana-red text-sm font-semibold">Instant Transfer</div>
                <div className="text-neutral-900 text-2xl font-bold">GHS 50.00</div>
                <div className="text-neutral-600 text-sm">MTN Data Bundle</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-neutral-900 mb-4">Complete VTU Services</h2>
            <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
              Everything you need for mobile recharge, data bundles, and bill payments across all major networks in Ghana.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="bg-neutral-50 hover:shadow-lg transition-shadow border border-neutral-200">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-ghana-red/10 rounded-lg flex items-center justify-center mb-4">
                    <service.icon className="w-6 h-6 text-ghana-red" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2" data-testid={`text-service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
                    {service.title}
                  </h3>
                  <p className="text-neutral-600 mb-4">{service.description}</p>
                  <ul className="text-sm text-neutral-600 space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex}>• {feature}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Supported Networks */}
      <section className="py-16 bg-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Supported Networks</h2>
            <p className="text-lg text-neutral-600">All major telecommunications networks in Ghana</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {networks.map((network, index) => (
              <Card key={index} className="bg-white text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-neutral-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <div className={`w-8 h-8 ${network.color} rounded-full`}></div>
                  </div>
                  <h3 className="font-semibold text-neutral-900" data-testid={`text-network-${network.name.toLowerCase().replace(/\s+/g, '-')}`}>
                    {network.name}
                  </h3>
                  <p className="text-sm text-neutral-600">{network.discount}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Recharge Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-neutral-900 mb-4">Quick Recharge</h2>
            <p className="text-xl text-neutral-600">Recharge any mobile number instantly</p>
          </div>

          <Card className="bg-neutral-50 border border-neutral-200">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-semibold text-neutral-900 mb-4">Popular Data Bundles</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {dataPackages.map((pkg, index) => (
                    <div key={index} className="p-4 border border-neutral-300 rounded-lg hover:border-ghana-red hover:bg-ghana-red/5 transition-colors text-center">
                      <div className="font-semibold text-lg">{pkg.data}</div>
                      <div className="text-sm text-neutral-600">{pkg.price}</div>
                      <div className="text-xs text-ghana-green">{pkg.validity}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center">
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="bg-ghana-red text-white px-8 py-4 h-auto text-lg font-semibold hover:bg-red-700"
                  data-testid="button-login-to-recharge"
                >
                  Login to Start Recharging
                </Button>
                <div className="flex items-center justify-center space-x-4 mt-4 text-sm text-neutral-600">
                  <div className="flex items-center space-x-1">
                    <Shield className="w-4 h-4 text-ghana-green" />
                    <span>Secure Payment</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <CheckCircle className="w-4 h-4 text-ghana-gold" />
                    <span>Instant Delivery</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Headphones className="w-4 h-4 text-trust-blue" />
                    <span>24/7 Support</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20 bg-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-neutral-900 mb-4">Transparent Pricing</h2>
            <p className="text-xl text-neutral-600 max-w-3xl mx-auto">
              Get the best rates for all networks. No hidden fees, clear pricing structure for individuals and resellers.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Individual Plan */}
            <Card className="bg-white border border-neutral-200">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-neutral-900 mb-2">Individual</h3>
                <p className="text-neutral-600 mb-4">Perfect for personal use</p>
                <div className="text-4xl font-bold text-ghana-red mb-2">0%</div>
                <p className="text-sm text-neutral-600 mb-8">Service fee on transactions</p>
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="w-full bg-neutral-900 text-white hover:bg-neutral-800"
                  data-testid="button-get-started-individual"
                >
                  Get Started Free
                </Button>
              </CardContent>
            </Card>

            {/* Reseller Plan */}
            <Card className="bg-gradient-to-br from-ghana-red to-red-600 text-white relative">
              <div className="absolute top-4 right-4 bg-ghana-gold text-neutral-900 px-3 py-1 rounded-full text-sm font-semibold">
                Most Popular
              </div>
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-2">Reseller</h3>
                <p className="text-white/80 mb-4">Start earning commissions</p>
                <div className="text-4xl font-bold mb-2">2-3%</div>
                <p className="text-sm text-white/80 mb-8">Commission on all sales</p>
                <Button 
                  onClick={() => window.location.href = '/api/login'}
                  className="w-full bg-white text-ghana-red hover:bg-neutral-100 font-semibold"
                  data-testid="button-become-reseller-plan"
                >
                  Become a Reseller
                </Button>
              </CardContent>
            </Card>

            {/* Enterprise Plan */}
            <Card className="bg-white border border-neutral-200">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-neutral-900 mb-2">Enterprise</h3>
                <p className="text-neutral-600 mb-4">For high-volume businesses</p>
                <div className="text-4xl font-bold text-ghana-red mb-2">3.5%</div>
                <p className="text-sm text-neutral-600 mb-8">Maximum commission rate</p>
                <Button 
                  className="w-full bg-neutral-900 text-white hover:bg-neutral-800"
                  data-testid="button-contact-sales"
                >
                  Contact Sales
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Link href="/pricing">
              <Button variant="outline" className="border-ghana-red text-ghana-red hover:bg-ghana-red hover:text-white">
                View Detailed Pricing
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust & Security */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-neutral-900 mb-4">Trust & Security</h2>
            <p className="text-xl text-neutral-600">Your security is our priority with bank-level encryption and secure payment processing</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {trustFeatures.map((feature, index) => (
              <Card key={index} className="bg-white text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-ghana-green/10 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <feature.icon className="w-8 h-8 text-ghana-green" />
                  </div>
                  <h3 className="font-semibold text-neutral-900 mb-2">{feature.title}</h3>
                  <p className="text-sm text-neutral-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Security Badges */}
          <div className="mt-16 flex justify-center items-center space-x-8 opacity-70">
            <div className="bg-white px-6 py-3 rounded-lg shadow-sm">
              <div className="text-sm font-semibold text-neutral-700">SSL SECURED</div>
            </div>
            <div className="bg-white px-6 py-3 rounded-lg shadow-sm">
              <div className="text-sm font-semibold text-neutral-700">PCI DSS COMPLIANT</div>
            </div>
            <div className="bg-white px-6 py-3 rounded-lg shadow-sm">
              <div className="text-sm font-semibold text-neutral-700">VERIFIED BY VISA</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-8 h-8 bg-gradient-to-r from-ghana-red via-ghana-gold to-ghana-green rounded-full flex items-center justify-center">
                  <Phone className="w-4 h-4 text-white" />
                </div>
                <span className="text-xl font-bold">GhanaPay<span className="text-ghana-red">VTU</span></span>
              </div>
              <p className="text-neutral-400 mb-6">Ghana's most trusted VTU platform for mobile recharge, data bundles, and bill payments.</p>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-lg font-semibold mb-6">Services</h4>
              <ul className="space-y-3">
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Airtime Recharge</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Data Bundles</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Bill Payments</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Reseller Program</Link></li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-lg font-semibold mb-6">Support</h4>
              <ul className="space-y-3">
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Help Center</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Contact Us</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">System Status</Link></li>
                <li><Link href="#" className="text-neutral-400 hover:text-white transition-colors">Security</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-lg font-semibold mb-6">Contact</h4>
              <ul className="space-y-3">
                <li className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-ghana-gold" />
                  <span className="text-neutral-400">+233 20 123 4567</span>
                </li>
                <li className="flex items-center space-x-3">
                  <span className="text-neutral-400">support@ghanapay.vtu</span>
                </li>
                <li className="flex items-center space-x-3">
                  <span className="text-neutral-400">Accra, Ghana</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Clock className="w-4 h-4 text-ghana-gold" />
                  <span className="text-neutral-400">24/7 Support</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-neutral-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-neutral-400 text-sm">
              © 2024 GhanaPayVTU. All rights reserved.
            </div>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Privacy Policy</Link>
              <Link href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Terms of Service</Link>
              <Link href="#" className="text-neutral-400 hover:text-white text-sm transition-colors">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
