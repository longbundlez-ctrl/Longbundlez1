import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import { Check, Star } from "lucide-react";

export default function Pricing() {
  const plans = [
    {
      name: "Individual",
      description: "Perfect for personal use",
      price: "0%",
      priceDescription: "Service fee on transactions",
      features: [
        "All network recharge",
        "Data bundle purchases",
        "Bill payments",
        "Transaction history",
        "24/7 customer support",
        "Mobile app access"
      ],
      cta: "Get Started Free",
      ctaVariant: "outline" as const,
      popular: false
    },
    {
      name: "Reseller",
      description: "Start earning commissions",
      price: "2-3%",
      priceDescription: "Commission on all sales",
      features: [
        "Everything in Individual",
        "Discounted rates",
        "Commission tracking",
        "Bulk operations",
        "Custom pricing tiers",
        "API access",
        "Priority support"
      ],
      cta: "Become a Reseller",
      ctaVariant: "default" as const,
      popular: true
    },
    {
      name: "Enterprise",
      description: "For high-volume businesses",
      price: "3.5%",
      priceDescription: "Maximum commission rate",
      features: [
        "Everything in Reseller",
        "API access",
        "White-label solutions",
        "Dedicated account manager",
        "Priority support",
        "Custom integrations",
        "Volume discounts"
      ],
      cta: "Contact Sales",
      ctaVariant: "outline" as const,
      popular: false
    }
  ];

  const networkPricing = [
    { network: "MTN Ghana", discount: "1%", color: "bg-yellow-500" },
    { network: "Telecel (Vodafone)", discount: "4%", color: "bg-red-500" },
    { network: "AirtelTigo", discount: "4%", color: "bg-blue-500" },
    { network: "Glo Ghana", discount: "2%", color: "bg-green-500" },
  ];

  const dataPackages = [
    { data: "1GB", mtn: "GHS 5.00", vodafone: "GHS 5.00", airteltigo: "GHS 5.00", glo: "GHS 5.00", validity: "7 days" },
    { data: "3GB", mtn: "GHS 12.00", vodafone: "GHS 12.00", airteltigo: "GHS 12.00", glo: "GHS 12.00", validity: "30 days" },
    { data: "6GB", mtn: "GHS 20.00", vodafone: "GHS 20.00", airteltigo: "GHS 20.00", glo: "GHS 20.00", validity: "30 days" },
    { data: "12GB", mtn: "GHS 35.00", vodafone: "GHS 35.00", airteltigo: "GHS 35.00", glo: "GHS 35.00", validity: "30 days" },
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header />
      
      {/* Page Header */}
      <section className="bg-gradient-to-r from-ghana-red to-ghana-green text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-4" data-testid="text-pricing-title">
            Transparent Pricing
          </h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Get the best rates for all networks. No hidden fees, clear pricing structure for individuals and resellers.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Account Plans */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Choose Your Plan</h2>
            <p className="text-lg text-neutral-600">Select the plan that best fits your needs</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <Card 
                key={plan.name} 
                className={`relative ${plan.popular ? 'bg-gradient-to-br from-ghana-red to-red-600 text-white' : 'bg-white'} ${plan.popular ? 'ring-2 ring-ghana-gold' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-ghana-gold text-neutral-900 px-4 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                      <Star className="w-4 h-4" />
                      <span>Most Popular</span>
                    </div>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-neutral-900'}`}>
                    {plan.name}
                  </CardTitle>
                  <p className={`mb-4 ${plan.popular ? 'text-white/80' : 'text-neutral-600'}`}>
                    {plan.description}
                  </p>
                  <div className="mb-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                  </div>
                  <p className={`text-sm ${plan.popular ? 'text-white/80' : 'text-neutral-600'}`}>
                    {plan.priceDescription}
                  </p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <Check className={`w-5 h-5 ${plan.popular ? 'text-ghana-gold' : 'text-ghana-green'}`} />
                        <span className={plan.popular ? 'text-white' : 'text-neutral-900'}>
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={plan.popular ? "secondary" : plan.ctaVariant}
                    className={`w-full ${plan.popular ? 'bg-white text-ghana-red hover:bg-neutral-100' : ''}`}
                    onClick={() => window.location.href = '/api/login'}
                    data-testid={`button-${plan.name.toLowerCase()}-plan`}
                  >
                    {plan.cta}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Network Discounts */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Network Discounts</h2>
            <p className="text-lg text-neutral-600">Enjoy discounts on all major networks in Ghana</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {networkPricing.map((network, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-neutral-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <div className={`w-8 h-8 ${network.color} rounded-full`}></div>
                  </div>
                  <h3 className="font-semibold text-neutral-900 mb-2" data-testid={`text-network-${network.network.toLowerCase().replace(/\s+/g, '-')}`}>
                    {network.network}
                  </h3>
                  <p className="text-2xl font-bold text-ghana-green">{network.discount}</p>
                  <p className="text-sm text-neutral-600">discount rate</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Data Package Pricing */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Data Package Prices</h2>
            <p className="text-lg text-neutral-600">Competitive pricing across all networks</p>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-neutral-200 bg-neutral-50">
                      <th className="text-left py-4 px-6 font-semibold">Data Package</th>
                      <th className="text-left py-4 px-6 font-semibold">MTN</th>
                      <th className="text-left py-4 px-6 font-semibold">Telecel</th>
                      <th className="text-left py-4 px-6 font-semibold">AirtelTigo</th>
                      <th className="text-left py-4 px-6 font-semibold">Glo</th>
                      <th className="text-left py-4 px-6 font-semibold">Validity</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dataPackages.map((pkg, index) => (
                      <tr key={index} className="border-b border-neutral-100 hover:bg-neutral-50">
                        <td className="py-4 px-6 font-semibold" data-testid={`text-package-${pkg.data}`}>
                          {pkg.data}
                        </td>
                        <td className="py-4 px-6">{pkg.mtn}</td>
                        <td className="py-4 px-6">{pkg.vodafone}</td>
                        <td className="py-4 px-6">{pkg.airteltigo}</td>
                        <td className="py-4 px-6">{pkg.glo}</td>
                        <td className="py-4 px-6 text-ghana-green">{pkg.validity}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* FAQ Section */}
        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-900 mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>How do commissions work?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-600">
                  Reseller and Enterprise accounts earn commissions on every successful transaction. 
                  Commissions are calculated as a percentage of the transaction amount and are automatically 
                  added to your account balance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Are there any hidden fees?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-600">
                  No hidden fees! Individual accounts pay no service fees. Reseller and Enterprise 
                  accounts earn commissions instead of paying fees. All pricing is transparent and 
                  clearly displayed.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How do I upgrade my account?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-600">
                  You can upgrade to a Reseller account instantly from your dashboard. 
                  Enterprise accounts require verification - contact our sales team for assistance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>What payment methods are accepted?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-neutral-600">
                  We accept mobile money (MTN, Vodafone, AirtelTigo), bank transfers, 
                  debit/credit cards, and other secure payment methods popular in Ghana.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA Section */}
        <section className="mt-16 text-center">
          <Card className="bg-gradient-to-r from-ghana-red to-ghana-green text-white">
            <CardContent className="p-12">
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-xl text-white/90 mb-8">
                Join thousands of satisfied customers across Ghana
              </p>
              <Button 
                size="lg"
                className="bg-white text-ghana-red hover:bg-neutral-100 font-semibold px-8"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-get-started-cta"
              >
                Get Started Today
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
