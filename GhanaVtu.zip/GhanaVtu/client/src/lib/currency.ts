/**
 * Format amount as Ghana Cedis currency
 * @param amount - The amount to format
 * @returns Formatted currency string
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-GH', {
    style: 'currency',
    currency: 'GHS',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Parse currency string to number
 * @param currencyString - The currency string to parse
 * @returns Parsed number
 */
export function parseCurrency(currencyString: string): number {
  // Remove currency symbols and parse
  const cleaned = currencyString.replace(/[^\d.-]/g, '');
  return parseFloat(cleaned) || 0;
}

/**
 * Format amount as simple currency without symbol
 * @param amount - The amount to format
 * @returns Formatted amount string
 */
export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}

/**
 * Validate if amount is valid for Ghana transactions
 * @param amount - The amount to validate
 * @returns Validation result
 */
export function validateAmount(amount: number): {
  valid: boolean;
  message?: string;
} {
  if (amount < 1) {
    return {
      valid: false,
      message: "Minimum amount is GHS 1.00"
    };
  }
  
  if (amount > 10000) {
    return {
      valid: false,
      message: "Maximum amount is GHS 10,000.00"
    };
  }
  
  return { valid: true };
}
