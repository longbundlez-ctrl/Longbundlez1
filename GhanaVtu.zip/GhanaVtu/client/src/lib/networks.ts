import type { Network } from "@shared/schema";

export interface NetworkInfo {
  id: string;
  name: string;
  displayName: string;
  color: string;
  bgColor: string;
  discountRate: string;
  logo?: string;
}

export const GHANA_NETWORKS: NetworkInfo[] = [
  {
    id: "mtn",
    name: "mtn",
    displayName: "MTN Ghana",
    color: "text-yellow-600",
    bgColor: "bg-yellow-500",
    discountRate: "1%",
  },
  {
    id: "vodafone",
    name: "vodafone", 
    displayName: "Telecel (Vodafone)",
    color: "text-red-600",
    bgColor: "bg-red-500",
    discountRate: "4%",
  },
  {
    id: "airteltigo",
    name: "airteltigo",
    displayName: "AirtelTigo", 
    color: "text-blue-600",
    bgColor: "bg-blue-500",
    discountRate: "4%",
  },
  {
    id: "glo",
    name: "glo",
    displayName: "Glo Ghana",
    color: "text-green-600", 
    bgColor: "bg-green-500",
    discountRate: "2%",
  },
];

/**
 * Get network info by ID
 */
export function getNetworkInfo(networkId: string): NetworkInfo | undefined {
  return GHANA_NETWORKS.find(network => network.id === networkId);
}

/**
 * Get network color classes
 */
export function getNetworkColors(networkId: string): {
  text: string;
  bg: string;
} {
  const network = getNetworkInfo(networkId);
  return {
    text: network?.color || "text-neutral-600",
    bg: network?.bgColor || "bg-neutral-500",
  };
}

/**
 * Validate Ghana phone number format
 */
export function validateGhanaPhoneNumber(phoneNumber: string): {
  valid: boolean;
  message?: string;
  formatted?: string;
} {
  // Remove all non-digit characters
  const cleaned = phoneNumber.replace(/\D/g, '');
  
  // Check if it starts with country code
  let number = cleaned;
  if (number.startsWith('233')) {
    number = '0' + number.slice(3);
  }
  
  // Validate format: should be 10 digits starting with 0
  if (!/^0[2-5][0-9]{8}$/.test(number)) {
    return {
      valid: false,
      message: "Please enter a valid Ghana phone number (e.g., 024 123 4567)"
    };
  }
  
  // Format as XXX XXX XXXX
  const formatted = `${number.slice(0, 3)} ${number.slice(3, 6)} ${number.slice(6)}`;
  
  return {
    valid: true,
    formatted
  };
}

/**
 * Get network from phone number prefix
 */
export function getNetworkFromPhoneNumber(phoneNumber: string): string | null {
  const cleaned = phoneNumber.replace(/\D/g, '');
  let number = cleaned;
  
  if (number.startsWith('233')) {
    number = '0' + number.slice(3);
  }
  
  if (number.length < 3) return null;
  
  const prefix = number.slice(0, 3);
  
  // MTN prefixes
  if (['024', '054', '055', '059'].includes(prefix)) {
    return 'mtn';
  }
  
  // Vodafone/Telecel prefixes  
  if (['020', '050'].includes(prefix)) {
    return 'vodafone';
  }
  
  // AirtelTigo prefixes
  if (['027', '057', '026', '056'].includes(prefix)) {
    return 'airteltigo';
  }
  
  // Glo prefixes
  if (['023', '053'].includes(prefix)) {
    return 'glo';
  }
  
  return null;
}
