import { useQuery } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/currency";
import { getNetworkColors } from "@/lib/networks";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, CheckCircle, Clock } from "lucide-react";

interface TransactionHistoryProps {
  limit?: number;
}

interface TransactionWithDetails {
  id: string;
  phoneNumber: string;
  amount: string;
  commission: string;
  status: string;
  description: string;
  createdAt: string;
  completedAt?: string;
  network: {
    id: string;
    displayName: string;
  };
  serviceType: {
    displayName: string;
  };
  servicePackage?: {
    name: string;
    dataAllowance?: string;
  };
}

export default function TransactionHistory({ limit }: TransactionHistoryProps) {
  const { data: transactions, isLoading, error } = useQuery<TransactionWithDetails[]>({
    queryKey: ["/api/transactions", ...(limit ? [`?limit=${limit}`] : [])],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: limit || 5 }).map((_, i) => (
          <div key={i} className="flex items-center space-x-4 p-4 border border-neutral-200 rounded-lg">
            <Skeleton className="w-10 h-10 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-1/2" />
            </div>
            <Skeleton className="h-6 w-16" />
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="mx-auto h-12 w-12 text-red-500 mb-4" />
        <p className="text-neutral-600">Failed to load transaction history</p>
      </div>
    );
  }

  if (!transactions || transactions.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Clock className="w-8 h-8 text-neutral-400" />
        </div>
        <p className="text-neutral-600 font-medium mb-2">No transactions yet</p>
        <p className="text-sm text-neutral-500">Your transaction history will appear here</p>
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'successful':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      successful: 'default',
      failed: 'destructive',
      pending: 'secondary',
      processing: 'outline'
    } as const;

    return (
      <Badge 
        variant={variants[status as keyof typeof variants] || 'secondary'}
        className="capitalize"
        data-testid={`badge-status-${status}`}
      >
        {status}
      </Badge>
    );
  };

  const maskPhoneNumber = (phoneNumber: string) => {
    if (phoneNumber.length <= 7) return phoneNumber;
    return phoneNumber.slice(0, 3) + '***' + phoneNumber.slice(-4);
  };

  return (
    <div className="space-y-4">
      {transactions.map((transaction) => {
        const colors = getNetworkColors(transaction.network.id);
        
        return (
          <div 
            key={transaction.id} 
            className="flex items-center space-x-4 p-4 border border-neutral-200 rounded-lg hover:shadow-sm transition-shadow"
            data-testid={`transaction-${transaction.id}`}
          >
            {/* Network Icon */}
            <div className={`w-10 h-10 ${colors.bg} rounded-full flex items-center justify-center flex-shrink-0`}>
              <div className="w-6 h-6 bg-white rounded-full"></div>
            </div>
            
            {/* Transaction Details */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <p className="font-medium text-neutral-900 truncate" data-testid={`text-transaction-service-${transaction.id}`}>
                  {transaction.servicePackage?.name || 
                   `${transaction.serviceType.displayName} ${formatCurrency(parseFloat(transaction.amount))}`}
                </p>
                {getStatusIcon(transaction.status)}
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-neutral-600">
                <span data-testid={`text-transaction-number-${transaction.id}`}>
                  {maskPhoneNumber(transaction.phoneNumber)}
                </span>
                <span data-testid={`text-transaction-date-${transaction.id}`}>
                  {new Date(transaction.createdAt).toLocaleDateString()}
                </span>
                {transaction.servicePackage?.dataAllowance && (
                  <span className="text-ghana-green font-medium">
                    {transaction.servicePackage.dataAllowance}
                  </span>
                )}
              </div>
            </div>
            
            {/* Amount and Status */}
            <div className="text-right">
              <p className="font-semibold text-neutral-900" data-testid={`text-transaction-amount-${transaction.id}`}>
                {formatCurrency(parseFloat(transaction.amount))}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                {getStatusBadge(transaction.status)}
              </div>
              {transaction.commission && parseFloat(transaction.commission) > 0 && (
                <p className="text-xs text-ghana-green mt-1" data-testid={`text-transaction-commission-${transaction.id}`}>
                  +{formatCurrency(parseFloat(transaction.commission))} commission
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
