import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { rechargeRequestSchema, type RechargeRequest } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { formatCurrency, validateAmount } from "@/lib/currency";
import { validateGhanaPhoneNumber, getNetworkFromPhoneNumber } from "@/lib/networks";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import NetworkSelector from "./NetworkSelector";
import { Loader2, CreditCard, Shield, CheckCircle, Headphones } from "lucide-react";

interface RechargeFormProps {
  showNetworkInfo?: boolean;
}

export default function RechargeForm({ showNetworkInfo = false }: RechargeFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPackage, setSelectedPackage] = useState<string>("");

  const form = useForm<RechargeRequest>({
    resolver: zodResolver(rechargeRequestSchema),
    defaultValues: {
      networkId: "",
      serviceTypeId: "",
      phoneNumber: "",
      amount: 0,
      packageId: "",
      paymentMethod: "mobile_money",
    },
  });

  const { data: networks, isLoading: networksLoading } = useQuery({
    queryKey: ["/api/networks"],
    retry: false,
  });

  const { data: serviceTypes, isLoading: serviceTypesLoading } = useQuery({
    queryKey: ["/api/service-types"],
    retry: false,
  });

  const { data: servicePackages, isLoading: packagesLoading } = useQuery({
    queryKey: [
      "/api/service-packages",
      form.watch("networkId"),
      form.watch("serviceTypeId")
    ],
    enabled: !!(form.watch("networkId") && form.watch("serviceTypeId")),
    retry: false,
  });

  const rechargeMutation = useMutation({
    mutationFn: async (data: RechargeRequest) => {
      const response = await apiRequest("POST", "/api/recharge", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Recharge Initiated",
        description: data.message || "Your recharge is being processed",
      });
      
      // Reset form
      form.reset();
      setSelectedPackage("");
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Recharge Failed",
        description: error.message || "Failed to process recharge",
        variant: "destructive",
      });
    },
  });

  // Auto-detect network from phone number
  useEffect(() => {
    const phoneNumber = form.watch("phoneNumber");
    if (phoneNumber && phoneNumber.length >= 10) {
      const detectedNetwork = getNetworkFromPhoneNumber(phoneNumber);
      if (detectedNetwork && detectedNetwork !== form.getValues("networkId")) {
        form.setValue("networkId", detectedNetwork);
      }
    }
  }, [form.watch("phoneNumber")]);

  // Reset package selection when network or service type changes
  useEffect(() => {
    form.setValue("packageId", "");
    setSelectedPackage("");
  }, [form.watch("networkId"), form.watch("serviceTypeId")]);

  const onSubmit = (data: RechargeRequest) => {
    // Validate phone number
    const phoneValidation = validateGhanaPhoneNumber(data.phoneNumber);
    if (!phoneValidation.valid) {
      form.setError("phoneNumber", {
        message: phoneValidation.message || "Invalid phone number"
      });
      return;
    }

    // Validate amount
    const amountValidation = validateAmount(data.amount);
    if (!amountValidation.valid) {
      form.setError("amount", {
        message: amountValidation.message || "Invalid amount"
      });
      return;
    }

    // Use formatted phone number
    const submissionData = {
      ...data,
      phoneNumber: phoneValidation.formatted || data.phoneNumber,
      packageId: selectedPackage || undefined,
    };

    rechargeMutation.mutate(submissionData);
  };

  const handlePackageSelect = (packageId: string) => {
    setSelectedPackage(packageId);
    form.setValue("packageId", packageId);
    
    // Find the package and set amount
    const pkg = servicePackages?.find((p: any) => p.id === packageId);
    if (pkg) {
      form.setValue("amount", parseFloat(pkg.amount));
    }
  };

  const watchedServiceType = form.watch("serviceTypeId");
  const watchedAmount = form.watch("amount");

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Network Selection */}
          <FormField
            control={form.control}
            name="networkId"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  {networksLoading ? (
                    <div className="space-y-3">
                      <Label>Select Network</Label>
                      <div className="grid grid-cols-2 gap-3">
                        {Array.from({ length: 4 }).map((_, i) => (
                          <div key={i} className="h-16 bg-neutral-100 rounded-lg animate-pulse"></div>
                        ))}
                      </div>
                    </div>
                  ) : networks ? (
                    <NetworkSelector
                      networks={networks}
                      selectedNetwork={field.value}
                      onNetworkChange={field.onChange}
                      disabled={rechargeMutation.isPending}
                      showDiscounts={showNetworkInfo}
                    />
                  ) : null}
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Service Type and Phone Number */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="serviceTypeId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={serviceTypesLoading || rechargeMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-service-type">
                        <SelectValue placeholder="Select Service" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {serviceTypes?.map((serviceType: any) => (
                        <SelectItem key={serviceType.id} value={serviceType.id}>
                          {serviceType.displayName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phoneNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="024 000 0000" 
                      {...field}
                      disabled={rechargeMutation.isPending}
                      data-testid="input-phone-number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Data Packages (only for data service) */}
          {watchedServiceType === "data" && servicePackages && servicePackages.length > 0 && (
            <div className="space-y-3">
              <Label>Popular Data Bundles</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {servicePackages.map((pkg: any) => (
                  <button
                    key={pkg.id}
                    type="button"
                    onClick={() => handlePackageSelect(pkg.id)}
                    disabled={rechargeMutation.isPending}
                    className={`
                      p-4 border rounded-lg transition-colors text-center text-sm
                      ${selectedPackage === pkg.id
                        ? 'border-ghana-red bg-ghana-red/5'
                        : 'border-neutral-300 hover:border-ghana-red hover:bg-ghana-red/5'
                      }
                      ${rechargeMutation.isPending ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                    data-testid={`button-package-${pkg.id}`}
                  >
                    <div className="font-semibold text-lg">{pkg.dataAllowance}</div>
                    <div className="text-neutral-600">{formatCurrency(parseFloat(pkg.amount))}</div>
                    <div className="text-xs text-ghana-green">{pkg.validity}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Amount and Payment Method */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount (GHS)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      placeholder="10.00" 
                      min="1" 
                      step="0.01"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      disabled={rechargeMutation.isPending || selectedPackage !== ""}
                      data-testid="input-amount"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                    disabled={rechargeMutation.isPending}
                  >
                    <FormControl>
                      <SelectTrigger data-testid="select-payment-method">
                        <SelectValue placeholder="Select Payment Method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="mobile_money">Mobile Money</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                      <SelectItem value="debit_card">Debit Card</SelectItem>
                      <SelectItem value="credit_card">Credit Card</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Submit Button */}
          <Button 
            type="submit" 
            className="w-full bg-ghana-red text-white hover:bg-red-700 h-12 text-lg font-semibold"
            disabled={rechargeMutation.isPending}
            data-testid="button-process-recharge"
          >
            {rechargeMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="mr-2 h-5 w-5" />
                Process Recharge - {watchedAmount > 0 ? formatCurrency(watchedAmount) : "GHS 0.00"}
              </>
            )}
          </Button>

          {/* Trust Indicators */}
          <div className="flex items-center justify-center space-x-6 text-sm text-neutral-600">
            <div className="flex items-center space-x-1">
              <Shield className="w-4 h-4 text-ghana-green" />
              <span>Secure Payment</span>
            </div>
            <div className="flex items-center space-x-1">
              <CheckCircle className="w-4 h-4 text-ghana-gold" />
              <span>Instant Delivery</span>
            </div>
            <div className="flex items-center space-x-1">
              <Headphones className="w-4 h-4 text-trust-blue" />
              <span>24/7 Support</span>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
