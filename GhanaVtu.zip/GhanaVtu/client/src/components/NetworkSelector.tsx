import { useState } from "react";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { getNetworkColors, getNetworkInfo } from "@/lib/networks";
import type { Network } from "@shared/schema";

interface NetworkSelectorProps {
  networks: Network[];
  selectedNetwork?: string;
  onNetworkChange: (networkId: string) => void;
  disabled?: boolean;
  showDiscounts?: boolean;
}

export default function NetworkSelector({
  networks,
  selectedNetwork,
  onNetworkChange,
  disabled = false,
  showDiscounts = true
}: NetworkSelectorProps) {
  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium text-neutral-700">
        Select Network
      </Label>
      <RadioGroup
        value={selectedNetwork}
        onValueChange={onNetworkChange}
        disabled={disabled}
        className="grid grid-cols-2 gap-3"
      >
        {networks.map((network) => {
          const networkInfo = getNetworkInfo(network.id);
          const colors = getNetworkColors(network.id);
          const isSelected = selectedNetwork === network.id;
          
          return (
            <div key={network.id} className="relative">
              <RadioGroupItem
                value={network.id}
                id={network.id}
                className="peer sr-only"
                data-testid={`radio-network-${network.id}`}
              />
              <Label
                htmlFor={network.id}
                className={`
                  flex items-center space-x-3 p-4 rounded-lg border-2 cursor-pointer transition-all
                  ${isSelected
                    ? 'border-ghana-red bg-ghana-red/5'
                    : 'border-neutral-300 hover:border-ghana-red/50'
                  }
                  ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
                `}
                data-testid={`label-network-${network.id}`}
              >
                {/* Network Logo/Icon */}
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${colors.bg}`}>
                  <div className="w-6 h-6 bg-white rounded-full"></div>
                </div>
                
                {/* Network Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-neutral-900 truncate">
                    {network.displayName}
                  </p>
                  {showDiscounts && (
                    <p className="text-xs text-ghana-green">
                      {network.discountRate}% discount
                    </p>
                  )}
                </div>
                
                {/* Selection Indicator */}
                {isSelected && (
                  <div className="w-5 h-5 bg-ghana-red rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                )}
              </Label>
            </div>
          );
        })}
      </RadioGroup>
    </div>
  );
}
