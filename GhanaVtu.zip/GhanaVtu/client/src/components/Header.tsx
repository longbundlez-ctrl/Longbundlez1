import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { formatCurrency } from "@/lib/currency";
import { Phone, Menu, User, LogOut } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Header() {
  const [location] = useLocation();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/", auth: true },
    { name: "Recharge", href: "/recharge", auth: true },
    { name: "Dashboard", href: "/dashboard", auth: true },
    { name: "Pricing", href: "/pricing", auth: false },
  ];

  const publicNavigation = [
    { name: "Pricing", href: "/pricing" },
  ];

  const userInitials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}`.toUpperCase()
    : user?.email?.[0]?.toUpperCase() || "U";

  return (
    <header className="bg-white shadow-sm border-b border-neutral-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer" data-testid="link-logo">
                <div className="w-8 h-8 bg-gradient-to-r from-ghana-red via-ghana-gold to-ghana-green rounded-full flex items-center justify-center">
                  <Phone className="w-4 h-4 text-white" />
                </div>
                <span className="text-xl font-bold text-neutral-900">
                  GhanaPay<span className="text-ghana-red">VTU</span>
                </span>
              </div>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {isAuthenticated ? (
              navigation
                .filter(item => item.auth === true)
                .map((item) => (
                  <Link 
                    key={item.name} 
                    href={item.href}
                    className={`text-neutral-600 hover:text-ghana-red transition-colors ${
                      location === item.href ? 'text-ghana-red font-medium' : ''
                    }`}
                    data-testid={`link-nav-${item.name.toLowerCase()}`}
                  >
                    {item.name}
                  </Link>
                ))
            ) : (
              publicNavigation.map((item) => (
                <Link 
                  key={item.name} 
                  href={item.href}
                  className={`text-neutral-600 hover:text-ghana-red transition-colors ${
                    location === item.href ? 'text-ghana-red font-medium' : ''
                  }`}
                  data-testid={`link-nav-${item.name.toLowerCase()}`}
                >
                  {item.name}
                </Link>
              ))
            )}
          </nav>

          {/* Desktop User Menu */}
          <div className="hidden md:flex items-center space-x-4">
            {isLoading ? (
              <div className="animate-pulse bg-neutral-200 h-8 w-20 rounded"></div>
            ) : isAuthenticated && user ? (
              <>
                {/* Balance Display */}
                <div className="text-sm text-neutral-600">
                  Balance: <span className="font-semibold text-ghana-green" data-testid="text-header-balance">
                    {formatCurrency(parseFloat(user.balance || "0"))}
                  </span>
                </div>
                
                {/* User Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full" data-testid="button-user-menu">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.profileImageUrl || ''} alt={user.firstName || 'User'} />
                        <AvatarFallback>{userInitials}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end" forceMount>
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none" data-testid="text-user-name">
                          {user.firstName ? `${user.firstName} ${user.lastName || ''}` : 'User'}
                        </p>
                        <p className="text-xs leading-none text-muted-foreground" data-testid="text-user-email">
                          {user.email}
                        </p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard" className="cursor-pointer" data-testid="link-dashboard-dropdown">
                        <User className="mr-2 h-4 w-4" />
                        Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="cursor-pointer text-red-600"
                      onClick={() => window.location.href = '/api/logout'}
                      data-testid="button-logout"
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center space-x-4">
                <Button 
                  variant="ghost"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-login"
                >
                  Login
                </Button>
                <Button 
                  className="bg-ghana-red text-white hover:bg-red-700"
                  onClick={() => window.location.href = '/api/login'}
                  data-testid="button-get-started"
                >
                  Get Started
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="button-mobile-menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col space-y-6 mt-6">
                  {/* User Info for Mobile */}
                  {isAuthenticated && user && (
                    <div className="border-b pb-6">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={user.profileImageUrl || ''} alt={user.firstName || 'User'} />
                          <AvatarFallback>{userInitials}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium" data-testid="text-mobile-user-name">
                            {user.firstName ? `${user.firstName} ${user.lastName || ''}` : 'User'}
                          </p>
                          <p className="text-sm text-neutral-600" data-testid="text-mobile-user-balance">
                            Balance: {formatCurrency(parseFloat(user.balance || "0"))}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Navigation Links */}
                  <nav className="flex flex-col space-y-4">
                    {isAuthenticated ? (
                      navigation
                        .filter(item => item.auth === true)
                        .map((item) => (
                          <Link 
                            key={item.name} 
                            href={item.href}
                            onClick={() => setMobileMenuOpen(false)}
                            className={`text-lg text-neutral-600 hover:text-ghana-red transition-colors ${
                              location === item.href ? 'text-ghana-red font-medium' : ''
                            }`}
                            data-testid={`link-mobile-${item.name.toLowerCase()}`}
                          >
                            {item.name}
                          </Link>
                        ))
                    ) : (
                      publicNavigation.map((item) => (
                        <Link 
                          key={item.name} 
                          href={item.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`text-lg text-neutral-600 hover:text-ghana-red transition-colors ${
                            location === item.href ? 'text-ghana-red font-medium' : ''
                          }`}
                          data-testid={`link-mobile-${item.name.toLowerCase()}`}
                        >
                          {item.name}
                        </Link>
                      ))
                    )}
                  </nav>

                  {/* Mobile Auth Buttons */}
                  <div className="border-t pt-6">
                    {isAuthenticated ? (
                      <Button 
                        variant="outline" 
                        className="w-full text-red-600 border-red-600 hover:bg-red-50"
                        onClick={() => window.location.href = '/api/logout'}
                        data-testid="button-mobile-logout"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                      </Button>
                    ) : (
                      <div className="space-y-3">
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => window.location.href = '/api/login'}
                          data-testid="button-mobile-login"
                        >
                          Login
                        </Button>
                        <Button 
                          className="w-full bg-ghana-red text-white hover:bg-red-700"
                          onClick={() => window.location.href = '/api/login'}
                          data-testid="button-mobile-get-started"
                        >
                          Get Started
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
