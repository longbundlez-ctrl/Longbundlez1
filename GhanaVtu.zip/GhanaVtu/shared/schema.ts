import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  decimal,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  phoneNumber: varchar("phone_number"),
  accountType: varchar("account_type").default("individual"), // individual, reseller, enterprise
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0.00"),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }).default("0.00"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Networks supported in Ghana
export const networks = pgTable("networks", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  displayName: varchar("display_name").notNull(),
  logoUrl: varchar("logo_url"),
  discountRate: decimal("discount_rate", { precision: 5, scale: 2 }).default("0.00"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Service types (airtime, data, sms)
export const serviceTypes = pgTable("service_types", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  displayName: varchar("display_name").notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
});

// Data bundles and service packages
export const servicePackages = pgTable("service_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  networkId: varchar("network_id").references(() => networks.id).notNull(),
  serviceTypeId: varchar("service_type_id").references(() => serviceTypes.id).notNull(),
  name: varchar("name").notNull(),
  description: text("description"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  validity: varchar("validity"), // "7 days", "30 days", etc.
  dataAllowance: varchar("data_allowance"), // "1GB", "3GB", etc.
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transactions
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  networkId: varchar("network_id").references(() => networks.id).notNull(),
  serviceTypeId: varchar("service_type_id").references(() => serviceTypes.id).notNull(),
  packageId: varchar("package_id").references(() => servicePackages.id),
  phoneNumber: varchar("phone_number").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).default("0.00"),
  status: varchar("status").default("pending"), // pending, processing, successful, failed
  paymentMethod: varchar("payment_method").notNull(),
  referenceId: varchar("reference_id"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// User balance transactions
export const balanceTransactions = pgTable("balance_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(), // credit, debit
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  referenceId: varchar("reference_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNetworkSchema = createInsertSchema(networks).omit({
  createdAt: true,
});

export const insertServiceTypeSchema = createInsertSchema(serviceTypes);

export const insertServicePackageSchema = createInsertSchema(servicePackages).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertBalanceTransactionSchema = createInsertSchema(balanceTransactions).omit({
  id: true,
  createdAt: true,
});

// Recharge request schema
export const rechargeRequestSchema = z.object({
  networkId: z.string().min(1, "Network is required"),
  serviceTypeId: z.string().min(1, "Service type is required"),
  phoneNumber: z.string().regex(/^0[2-5][0-9]{8}$/, "Please enter a valid Ghana phone number"),
  amount: z.number().min(1, "Amount must be at least GHS 1.00"),
  packageId: z.string().optional(),
  paymentMethod: z.string().min(1, "Payment method is required"),
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Network = typeof networks.$inferSelect;
export type ServiceType = typeof serviceTypes.$inferSelect;
export type ServicePackage = typeof servicePackages.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type BalanceTransaction = typeof balanceTransactions.$inferSelect;
export type RechargeRequest = z.infer<typeof rechargeRequestSchema>;

export type InsertNetwork = z.infer<typeof insertNetworkSchema>;
export type InsertServiceType = z.infer<typeof insertServiceTypeSchema>;
export type InsertServicePackage = z.infer<typeof insertServicePackageSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type InsertBalanceTransaction = z.infer<typeof insertBalanceTransactionSchema>;
