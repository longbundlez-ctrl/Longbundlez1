# GhanaPayVTU - VTU Service Platform

## Overview

GhanaPayVTU is a full-stack web application for virtual top-up (VTU) services in Ghana. The platform enables users to recharge airtime, purchase data bundles, pay bills, and participate in a reseller program across major Ghanaian telecom networks (MTN, Telecel/Vodafone, AirtelTigo, Glo).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server components:

- **Frontend**: React with TypeScript using Vite for development and build tooling
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with OpenID Connect
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite build system
- **Routing**: Wouter for client-side routing
- **UI Components**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom Ghana-themed color palette
- **State Management**: TanStack Query for API state, React hooks for local state
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Server**: Express.js with TypeScript using ES modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Authentication**: Passport.js with OpenID Connect strategy for Replit Auth
- **Session Management**: Express sessions with PostgreSQL store
- **API Design**: RESTful endpoints with structured error handling

### Database Schema
- **Users**: Profile information, balance, commission rates, account types
- **Networks**: Telecom operators (MTN, Vodafone, AirtelTigo, Glo)
- **Service Types**: Categories (airtime, data, bills)
- **Service Packages**: Specific offerings per network
- **Transactions**: User purchases and recharges
- **Balance Transactions**: Account balance changes
- **Sessions**: Authentication session storage

## Data Flow

1. **User Authentication**: OpenID Connect flow with Replit Auth, session persistence in PostgreSQL
2. **Service Discovery**: Frontend queries available networks, service types, and packages
3. **Transaction Processing**: Form validation → API request → database transaction → response
4. **Balance Management**: Real-time balance updates with transaction history
5. **Commission Tracking**: Automatic commission calculation for reseller accounts

## External Dependencies

### Database & ORM
- **PostgreSQL**: Primary database (configured for Neon serverless)
- **Drizzle ORM**: Type-safe database operations with migration support
- **connect-pg-simple**: PostgreSQL session store

### Authentication
- **Replit Auth**: OpenID Connect authentication provider
- **Passport.js**: Authentication middleware
- **openid-client**: OIDC client implementation

### Frontend Libraries
- **React**: UI framework with hooks
- **TanStack Query**: Server state management
- **React Hook Form**: Form handling and validation
- **Zod**: Schema validation
- **Wouter**: Lightweight routing
- **Tailwind CSS**: Utility-first styling
- **Radix UI**: Accessible component primitives

### Development Tools
- **Vite**: Development server and build tool
- **TypeScript**: Type safety
- **ESLint**: Code linting
- **Replit integration**: Development environment support

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express backend
- **Hot Reloading**: Vite HMR for frontend, tsx for backend reloading
- **Environment Variables**: DATABASE_URL, SESSION_SECRET, REPLIT_DOMAINS

### Production Build
- **Frontend Build**: Vite builds React app to `dist/public`
- **Backend Build**: esbuild bundles Express server to `dist/index.js`
- **Static Serving**: Express serves built frontend in production
- **Process Management**: Single Node.js process serving both frontend and API

### Database Management
- **Migrations**: Drizzle Kit for schema migrations
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Session Storage**: PostgreSQL-backed express sessions

The architecture prioritizes type safety, developer experience, and scalability while maintaining simplicity for a VTU service platform targeting the Ghanaian market.